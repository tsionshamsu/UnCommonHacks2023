import objectdraw.FilledRect;

public interface Shootable {
	public boolean tryShoot(FilledRect r);
}
